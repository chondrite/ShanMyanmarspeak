# ရှမ်းမြန်မာစကားပြော — V0.8 Final

**အရှည်ကောက်:** ရှမ်းစာလေ့လာရေး + ရှမ်း–မြန်မာအဘိဓာန် + စာအုပ်ဖတ်ရှုရေး App

## Included
- Offline-first dictionary prototype
- Shan text + Myanmar pronunciation + Myanmar meaning
- Local account/login
- Favorites / History
- Security & Privacy
- Books/library section
- No ads, analytics, or tracking SDK
- Microphone permission only for voice input

## Build with Android Studio
1. Open this project folder in Android Studio.
2. Allow Android Studio to install/sync the required Android SDK and Gradle components.
3. Run **Build > Make Project**.
4. Then choose **Build > Build APK(s)**.
5. Debug APK will be under `app/build/outputs/apk/debug/`.

## Important
This environment cannot compile Android APKs because Android SDK/Gradle build tools are not installed here. The project has been cleaned and configured for Android Studio.

The included book-page image is a sample/reference only. Public distribution of book content should use material you have permission to reproduce.
