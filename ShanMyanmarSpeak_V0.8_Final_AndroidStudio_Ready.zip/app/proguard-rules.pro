# ShanMyanmarSpeak release rules
