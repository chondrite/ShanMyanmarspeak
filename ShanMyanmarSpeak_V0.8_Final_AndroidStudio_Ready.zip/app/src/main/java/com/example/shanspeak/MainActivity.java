package com.example.shanspeak;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import java.security.SecureRandom;
import java.security.MessageDigest;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_AUDIO = 100;
    private static final int REQ_SPEECH = 101;
    private TextToSpeech tts;
    private TextView status;
    private SharedPreferences prefs;
    private boolean locked = false;
    private boolean loggedIn = false;
    private static final String ACCOUNT_PREFS = "local_account";
    private static final String KEY_ALIAS = "ShanSpeakLocalAccountKey";
    private final java.util.ArrayList<String> favorites = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> history = new java.util.ArrayList<>();

    private final Map<String, String> dictionary = new LinkedHashMap<String, String>() {{
        put("မႂ်ႇသုင်", "မင်္ဂလာပါ");
        put("ၵိၼ်ၶဝ်ႈယဝ်ႉႁႃႉ", "ထမင်းစားပြီးပြီလား");
        put("ၶႃႈ", "ကျွန်တော် / ကျွန်မ");
        put("ၸဝ်ႈ", "သင် / မင်း");
        put("ၶေႃႈၸႂ်", "စိတ်");
        put("ႁၵ်ႉ", "ချစ်သည်");
        put("ၶွပ်ႈၸႂ်", "ကျေးဇူးတင်ပါတယ်");
        put("လီယူႇ", "ကောင်းပါတယ်");
        put("ယူႇလီႁႃႉ", "နေကောင်းလား");
        put("ၸိုၼ်ႈသႂ်", "မင်္ဂလာ / ကြည်လင်");
        put("ၵႂႃႇ", "သွားသည်");
        put("မႃး", "လာသည်");
        put("ၵိၼ်", "စားသည်");
        put("ၼမ်ႉ", "ရေ");
        put("ၶဝ်ႈ", "ထမင်း / ဆန်");
        put("ႁိူၼ်း", "အိမ်");
        put("တီႈလႂ်", "ဘယ်မှာလဲ");
        put("ၸွမ်း", "အတူ / လိုက်");
        put("ယိၼ်း", "ဝမ်းသာသည် / ခံစားသည်");
        put("လၢႆး", "နည်းလမ်း");
        put("မႂ်ႇ", "အသစ်");
        put("ၵႂၢမ်း", "စကား");
        put("ၽူႈ", "လူ / သူ");
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        prefs = getSharedPreferences("privacy", MODE_PRIVATE);
        locked = prefs.getBoolean("app_lock", false);
        if (locked) showUnlockDialog();

        if (!hasLocalAccount()) {
            showCreateAccountDialog();
        } else {
            showLoginDialog();
        }
        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnSpeak = findViewById(R.id.btnSpeak);
        EditText search = findViewById(R.id.searchBox);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                // Prefer Shan (shn-MM). Availability depends on the installed TTS engine/voice pack.
                Locale shan = new Locale("shn", "MM");
                int shanResult = tts.setLanguage(shan);
                if (shanResult == TextToSpeech.LANG_MISSING_DATA ||
                    shanResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("my", "MM"));
                    status.setText("ရှမ်း Native Voice မရှိသေးပါ။ လက်ရှိဖုန်း TTS ကို fallback အဖြစ်အသုံးပြုမည်။");
                } else {
                    status.setText("ရှမ်းအသံထွက်အတွက် TTS ကို အသင့်ပြင်ထားပါသည်။");
                }
            }
        });

        btnPlay.setOnClickListener(v -> {
            if (!requireLogin()) return;
            if (tts != null) {
                // Prefer speaking the Shan text itself; if the device lacks Shan TTS,
                // the initialization above falls back to Burmese TTS.
                tts.speak("မႂ်ႇသုင်", TextToSpeech.QUEUE_FLUSH, null, "shan_demo");
                status.setText("🔊 ရှမ်းအသံထွက်ကို ဖွင့်နေပါသည်။");
            }
        });

        btnSpeak.setOnClickListener(v -> {
            if (!requireLogin()) return;
            startSpeechInput();
        });

        findViewById(R.id.btnDictionary).setOnClickListener(v -> {
            if (!requireLogin()) return;
            lookup(search);
        });

        findViewById(R.id.btnFavorite).setOnClickListener(v -> {
            if (locked) {
                showUnlockDialog();
                return;
            }
            String q = search.getText().toString().trim();
            if (!q.isEmpty() && !favorites.contains(q)) {
                favorites.add(q);
                status.setText("❤️ Favorites ထဲသို့ သိမ်းပြီးပါပြီ: " + q);
            } else if (q.isEmpty()) {
                status.setText("သိမ်းလိုသော စကားလုံးကို အရင်ရှာပါ။");
            }
        });

        findViewById(R.id.btnHistory).setOnClickListener(v -> {
            if (locked) {
                showUnlockDialog();
                return;
            }
            if (history.isEmpty()) {
                status.setText("🕘 ရှာဖွေမှတ်တမ်း မရှိသေးပါ။");
            } else {
                StringBuilder sb = new StringBuilder("🕘 ရှာဖွေမှတ်တမ်း\n");
                for (int i = history.size() - 1; i >= 0; i--) {
                    sb.append("• ").append(history.get(i)).append("\n");
                }
                status.setText(sb.toString());
            }
        });

        findViewById(R.id.btnBooks).setOnClickListener(v -> showBooksDialog());

        findViewById(R.id.btnSecurity).setOnClickListener(v -> showSecurityDialog());

        findViewById(R.id.btnAccount).setOnClickListener(v -> showAccountDialog());

        search.setOnEditorActionListener((v, actionId, event) -> {
            lookup(search);
            return true;
        });
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) {
            return value;
        }
    }

    private boolean requireLogin() {
        if (!loggedIn) {
            showLoginDialog();
            return false;
        }
        return true;
    }

    private boolean hasLocalAccount() {
        return getSharedPreferences(ACCOUNT_PREFS, MODE_PRIVATE).contains("username")
                && getSharedPreferences(ACCOUNT_PREFS, MODE_PRIVATE).contains("password_hash");
    }

    private void showSecurityDialog() {
        final String[] options = {"PIN ဖွင့်/ပြောင်းရန်", "App Lock ဖွင့်/ပိတ်ရန်", "History အားလုံးဖျက်ရန်"};
        new android.app.AlertDialog.Builder(this)
                .setTitle("🔐 Security & Privacy")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) setPin();
                    else if (which == 1) toggleLock();
                    else {
                        history.clear();
                        status.setText("History ကို ဖျက်ပြီးပါပြီ။");
                    }
                }).show();
    }

    private void setPin() {
        final EditText input = new EditText(this);
        input.setHint("PIN 4–6 လုံး");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new android.app.AlertDialog.Builder(this)
                .setTitle("PIN သတ်မှတ်ရန်")
                .setView(input)
                .setPositiveButton("သိမ်းမည်", (d, w) -> {
                    String pin = input.getText().toString();
                    if (pin.length() >= 4 && pin.length() <= 6) {
                        prefs.edit().putString("pin_hash", sha256(pin)).apply();
                        Toast.makeText(this, "PIN ကို လုံခြုံစွာသိမ်းပြီးပါပြီ", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "PIN 4–6 လုံး ထည့်ပါ", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("မလုပ်တော့ပါ", null).show();
    }

    private void toggleLock() {
        String pinHash = prefs.getString("pin_hash", "");
        if (pinHash.isEmpty()) {
            setPin();
            return;
        }
        locked = !locked;
        prefs.edit().putBoolean("app_lock", locked).apply();
        status.setText(locked ? "🔒 App Lock ဖွင့်ထားပါသည်။" : "🔓 App Lock ပိတ်ထားပါသည်။");
    }

    private void showUnlockDialog() {
        String pinHash = prefs.getString("pin_hash", "");
        if (pinHash.isEmpty()) {
            locked = false;
            return;
        }
        final EditText input = new EditText(this);
        input.setHint("PIN");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new android.app.AlertDialog.Builder(this)
                .setTitle("🔒 PIN ထည့်ပါ")
                .setView(input)
                .setPositiveButton("ဖွင့်မည်", (d, w) -> {
                    if (pinHash.equals(sha256(input.getText().toString()))) {
                        locked = false;
                        status.setText("App Lock ဖြုတ်ပြီးပါပြီ။");
                    } else {
                        Toast.makeText(this, "PIN မမှန်ပါ", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("ပယ်ဖျက်", null).show();
    }

    private void lookup(EditText search) {
        String q = search.getText().toString().trim();
        if (q.isEmpty()) {
            status.setText("ရှမ်းစာ သို့မဟုတ် မြန်မာစာ ရိုက်ထည့်ပါ။");
            return;
        }

        if (dictionary.containsKey(q)) {
            addHistory(q);
            status.setText("ရှမ်းစာ: " + q + "\nမြန်မာအဓိပ္ပာယ်: " + dictionary.get(q));
            return;
        }

        for (Map.Entry<String, String> entry : dictionary.entrySet()) {
            if (entry.getValue().equals(q)) {
                addHistory(q);
                status.setText("မြန်မာစာ: " + q + "\nရှမ်းစာ: " + entry.getKey());
                return;
            }
        }

        status.setText("ရှာမတွေ့သေးပါ: " + q + "\nအဘိဓာန်ဒေတာကို နောက်ထပ်စကားလုံးများဖြင့် တိုးချဲ့နိုင်သည်။");
    }

    private void addHistory(String q) {
        history.remove(q);
        history.add(q);
        while (history.size() > 20) history.remove(0);
    }

    private void startSpeechInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "my-MM");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "စကားပြောပါ");
        try {
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            status.setText("ဖုန်း၏ Speech Recognition စနစ် မရရှိပါ။");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                status.setText("အသံမှတ်တမ်း: " + results.get(0) +
                        "\nရှမ်းဘာသာပြန် API/ဒေတာစနစ်ကို နောက်အဆင့်တွင် ချိတ်ဆက်နိုင်သည်။");
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
